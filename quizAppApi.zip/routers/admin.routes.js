const express = require("express");
const router = express.Router();
const Admin = require("../models/adminModel");

router.post("/", async (req, res) => {
  const { name, email } = req.body;
  try {
    const admin = await Admin.create({ name, email });
    res.status(201).json({ message: "Admin created successfully", admin });
  } catch (err) {
    console.error("Error creating admin:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

// GET all admins
router.get("/", async (req, res) => {
  try {
    const admins = await Admin.find();
    res.status(200).json(admins);
  } catch (err) {
    console.error("Error fetching admins:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

// GET a specific admin by ID
router.get("/:adminId", async (req, res) => {
  const adminId = req.params.adminId;
  try {
    const admin = await Admin.findById(adminId);
    if (!admin) {
      res.status(404).json({ error: "Admin not found" });
    } else {
      res.status(200).json(admin);
    }
  } catch (err) {
    console.error("Error fetching admin:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

// PATCH update a specific admin by ID
router.patch("/:adminId", async (req, res) => {
  const adminId = req.params.adminId;
  const { name, email } = req.body;
  try {
    const updatedAdmin = await Admin.findByIdAndUpdate(
      adminId,
      { name, email },
      { new: true }
    );
    if (!updatedAdmin) {
      res.status(404).json({ error: "Admin not found" });
    } else {
      res.status(200).json(updatedAdmin);
    }
  } catch (err) {
    console.error("Error updating admin:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

// DELETE a specific admin by ID
router.delete("/:adminId", async (req, res) => {
  const adminId = req.params.adminId;
  try {
    const deletedAdmin = await Admin.findByIdAndDelete(adminId);
    if (!deletedAdmin) {
      res.status(404).json({ error: "Admin not found" });
    } else {
      res.status(200).json({ message: "Admin deleted successfully" });
    }
  } catch (err) {
    console.error("Error deleting admin:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

module.exports = router;
