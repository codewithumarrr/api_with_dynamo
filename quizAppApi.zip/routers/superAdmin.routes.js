const express = require("express");
const router = express.Router();
const SuperAdmin = require("../models/superAdminModel");

// GET all super admins
router.get("/", async (req, res) => {
  try {
    const superAdmins = await SuperAdmin.find();
    res.status(200).json(superAdmins);
  } catch (err) {
    console.error("Error fetching super admins:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

// POST a new super admin
router.post("/", async (req, res) => {
  const { name, email } = req.body;
  try {
    const newSuperAdmin = await SuperAdmin.create({ name, email });
    res
      .status(201)
      .json({
        message: "Super admin added successfully",
        superAdmin: newSuperAdmin,
      });
  } catch (err) {
    console.error("Error adding super admin:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

module.exports = router;
